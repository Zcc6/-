package com.swun.service;

public interface IShellService {
    void createRepo(String username,String repoName);
    void login();
}
